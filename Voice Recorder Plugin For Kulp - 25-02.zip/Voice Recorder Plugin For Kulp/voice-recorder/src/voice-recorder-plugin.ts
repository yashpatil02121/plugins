import { KulpElement, html, css, register, prop } from "kulp-kit";
import { _ } from "kulp-kit";

@register("voice-recorder.voice-recorder-plugin")
export class VoiceRecorder extends KulpElement {
  @prop({ type: String }) audioFormat = "audio/webm"; 
  @prop({ type: Number }) maxDuration = 60; 
  @prop({ type: Boolean }) enableTimer = false; 
  @prop({ type: Boolean }) showAudioPlayer = false; 
  @prop({ type: Boolean }) disableRecording = false; 
  @prop({ type: Boolean }) recordingIndicator = false; 
  @prop({ type: Boolean }) autoPlayAfterRecord = false; 
  @prop({ type: Boolean }) saveToLocalStorage = false; 
  @prop({ type: String }) recordingText = "..."; 
  @prop({ type: String }) idleText = "🎙️"; 
  @prop({ type: String }) audioPlayerPosition = "bottom"; 
  @prop({ type: String }) outputVariable = "";
  @prop({ type: String }) buttonColorMode = "primary";  
  @prop({ type: String }) recordingButtonColorMode = "accent";  

  isRecording = false;
  audioURL = "";
  mediaRecorder: MediaRecorder | null = null;
  audioChunks: BlobPart[] = [];
  stream: MediaStream | null = null;
  showPopup = false;

  static styles = css`
    .recorder-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 10px;
    }
    .record-button {
      padding: 10px 10px;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      font-size: 16px;
      color: white;
      user-select: none;
      transition: background-color 0.3s ease-in-out;
    }
    .popup-audio-player {
      min-width: 260px;
      position: fixed;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0, 0, 0, 0.85);
      padding: 12px;
      border-radius: 8px;
      z-index: 1000;
      display: flex;
      flex-direction: column;
      align-items: center;
      box-shadow: 0 4px 12px rgba(75, 75, 75, 0.3);
      min-width: 82vw;
    }
    .popup-close {
      position: absolute;
      top: 5px;
      right: 5px;
      height: 20px;
      width: 20px;
      background: rgba(255, 255, 255, 0.8);
      border: none;
      color: black;
      font-size: 10px;
      cursor: pointer;
      border-radius: 50%;
      z-index: 1001;
      transition: opacity 0.2s ease-in-out;
    }
    .popup-close:hover {
      opacity: 0.6;
      background: white;
    }
  `;

  /** ✅ Function to Get Color Variable or Direct Color */
  getColorValue(colorMode: string) {
    const themeColors = ["primary", "secondary", "tertiary", "accent", "highlight", "text", "background"];
    
    return themeColors.includes(colorMode) 
      ? `var(--color-${colorMode}, rgba(228, 228, 228, 0.85))`  // Use Theme Color
      : colorMode; // Direct Color (red, blue, yellow, etc.)
  }

  async startRecording() {
    if (this.disableRecording) return;
    try {
      let mimeType = this.audioFormat;
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        console.warn(`⚠️ Format ${mimeType} is not supported! Falling back to WebM.`);
        mimeType = "audio/webm"; // Fallback to WebM
      }

      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType });

      this.audioChunks = [];
      this.isRecording = true;
      this.showPopup = false;
      this.requestUpdate();

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.audioChunks.push(event.data);
      };

      this.mediaRecorder.onstop = async () => {
        if (this.audioChunks.length) {
          const audioBlob = new Blob(this.audioChunks, { type: mimeType });

          if (this.kulp?.context && this.outputVariable) {
            _.set(this.kulp.context, this.outputVariable, audioBlob);
          }

          this.audioURL = URL.createObjectURL(audioBlob);

          if (this.saveToLocalStorage) {
            localStorage.setItem("lastRecording", JSON.stringify(await audioBlob.arrayBuffer()));
          }

          this.showPopup = true;
          this.requestUpdate();

          if (this.autoPlayAfterRecord) {
            const audio = new Audio(this.audioURL);
            audio.play();
          }
        }
        this.audioChunks = [];
      };

      this.mediaRecorder.start();
    } catch (error) {
      console.error("❌ Microphone access error:", error);
    }
  }

  stopRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;

      if (this.stream) {
        this.stream.getTracks().forEach((track) => track.stop());
        this.stream = null;
      }

      this.requestUpdate();
    }
  }

  closePopup() {
    this.showPopup = false;
    this.requestUpdate();
  }

  render() {
    return html`
      <div class="recorder-container">
        <button 
          class="record-button ${this.isRecording ? 'recording' : ''}" 
          @pointerdown="${this.startRecording}" 
          @pointerup="${this.stopRecording}" 
          ?disabled=${this.disableRecording}
          style="background-color: ${this.isRecording ? this.getColorValue(this.recordingButtonColorMode) : this.getColorValue(this.buttonColorMode)};"
        >
          <span style="user-select: none;">${this.isRecording ? this.recordingText : this.idleText}</span>
        </button>

        ${this.showAudioPlayer && this.audioURL && this.showPopup ? html`
          <div class="popup-audio-player" 
               style="${this.audioPlayerPosition === 'top' ? 'top: 15%;' : 
                      this.audioPlayerPosition === 'middle' ? 'top: 50%; transform: translate(-50%, -50%);' :
                      'bottom: 15%;'}">
            <button class="popup-close" @click="${this.closePopup}">✖</button>
            <audio class="audio-player" controls src="${this.audioURL}"></audio>
          </div>` : ""}
      </div>
    `;
  }
}
